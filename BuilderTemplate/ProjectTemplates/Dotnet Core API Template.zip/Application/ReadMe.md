﻿# Application Layer

This layer contains all application logic.