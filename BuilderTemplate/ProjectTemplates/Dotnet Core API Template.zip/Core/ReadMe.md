﻿# Core Layer

This layer is an infrastructure for application.