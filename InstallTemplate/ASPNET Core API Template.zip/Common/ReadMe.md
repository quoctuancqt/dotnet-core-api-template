﻿#Common Layer

This will include all common concern.