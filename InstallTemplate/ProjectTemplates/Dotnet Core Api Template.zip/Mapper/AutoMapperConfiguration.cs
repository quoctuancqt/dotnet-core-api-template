﻿namespace $safeprojectname$
{
    public static class AutoMapperConfiguration
    {
        public static void Config()
        {
            //AutoMapper.$safeprojectname$.Initialize(cfg =>
            //{
            //    cfg.AddProfile();
            //});
        }

        public static void Reset()
        {
            //AutoMapper.$safeprojectname$.Reset();
        }
    }
}
