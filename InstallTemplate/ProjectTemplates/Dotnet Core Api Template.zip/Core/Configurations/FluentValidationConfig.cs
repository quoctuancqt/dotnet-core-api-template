﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Configurations
{
    public static class FluentValidationConfig
    {
        public static void AddValidators(this IServiceCollection services)
        {
            
        }
    }
}
