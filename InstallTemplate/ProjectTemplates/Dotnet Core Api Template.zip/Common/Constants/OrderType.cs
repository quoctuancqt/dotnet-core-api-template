﻿namespace $safeprojectname$.Constants
{
    public enum OrderType
    {
        Ascending,
        Descending
    }
}
